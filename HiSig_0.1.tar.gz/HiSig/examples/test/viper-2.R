library(HiSig)
library(viper)

e = 'AR.GDS4113'

letter = "E"
xfname <- paste0("matrix_", e, "_normal_", letter, ".csv" )
yfname <- paste0("zscores_", e, ".csv")
genes <- readLines(paste0("genes_", e, ".csv"))
terms <- readLines("tfs.csv")

# xfname <- 'conn.txt'
# yfname <- 'response.txt'
# genes <- readLines('target.txt')
# terms <- readLines('tf.txt')


data <- load_data(xfname, yfname, genes, terms, index1=F)

regulon2 <- sparse2aracne(data)

signature <- data$response
row.names(signature) <- data$genes

#null model
nullmodel2 <- replicate(1000, sample(signature))
# nullmodel3 <- sample(signature)
# for(i in 1:99){
#   nullmodel3 <- cbind(nullmodel3, sample(signature))
# }

#msViper
# mrs <- msviper(signature, regulon, nullmodel, verbose=T)
mrs <- msviper(signature, regulon2, nullmodel2, verbose=T)

#save mrs object
save(mrs, file=paste0(args$e, "_", letter, ".RData"))
